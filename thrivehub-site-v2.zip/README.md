# ThriveHub (V2) — Quick Start

**Public URL (after GitHub Pages):** `https://DGR125.github.io/thrivehub/`

## What changed in V2
- Removed the FASD category from the home page
- Added **Additional Resources** page with FASD and many more free links
- Prominent link to your **Teacher Resources blog** (thestudentwellbeing.wordpress.com)
- Australian English throughout

## How to publish
1. Create a public repo named `thrivehub` under `DGR125`.
2. Upload all files in this folder (keep `index.html` at the repo root).
3. Settings → Pages → Source: `main` / `/root`.
4. Your link will be `https://DGR125.github.io/thrivehub/`.
